<?php
/**
 * Plugin Name: Clark - Web Wise Reports
 * Description: Current and monthly technical reports helper for sites.
 * Version: 1.1.1
 * Author: Tomorrow Happens
 * Author URI: https://hostwithclark.com/
 * Developer: Alex Fesenko
 * Text Domain: cw-report
 * Domain Path: /languages
 * Update URI:  https://raw.githubusercontent.com/Tomorrow-Happens/cw-report-update/main/version.json
 */

if (!defined('ABSPATH')) {
    exit();
}

if (!class_exists('CW_Tech_Report')):
    /**
     * Main CW_Tech_Report class.
     */
    final class CW_Tech_Report
    {
        /**
         * @var string
         */
        public $version;

        /**
         * @var string
         */
        public $UpdateURI;

        /**
         * @var string
         */
        public $plugin_slug;

        /**
         * @var string
         */
        public $cache_key = 'cw_report_plugin_update';

        /**
         * @var bool
         */
        public $cache_allowed = false;

        /**
         * @var obj
         */
        public $checked;

        /**
         *  Instance.
         *
         * @var CW_Tech_Report the Instance
         */
        protected static $_instance;

        /**
         * Main CW_Tech_Report Instance.
         *
         * Ensures that only one instance of TH_Tech_Report exists in memory at any one
         * time. Also prevents needing to define globals all over the place.
         *
         * @return CW_Tech_Report
         */
        public static function instance()
        {
            if (is_null(self::$_instance)) {
                try {
                    self::$_instance = new self();
                } catch (\Throwable $error) {
                    return null;
                }
            }

            return self::$_instance;
        }

        /**
         * Get running.
         *
         * @return void
         */
        public function __construct()
        {
            $this->setup_constants();
            $this->includes();
            $this->init_hooks();
        }

        /**
         * Setup plugin constants.
         *
         * @return void
         */
        private function setup_constants()
        {

            // Plugin Folder Path.
            if (!defined('CW_PLUGIN_DIR')) {
                define('CW_PLUGIN_DIR', plugin_dir_path(__FILE__));
            }

            // Plugin Folder Path.
            if (!defined('CW_PLUGIN_ID')) {
                define(
                    'CW_PLUGIN_ID',
                    str_replace(WP_PLUGIN_DIR . '/', '', __FILE__)
                );
            }

            // Plugin Folder URL.
            if (!defined('CW_PLUGIN_URL')) {
                define('CW_PLUGIN_URL', plugin_dir_url(__FILE__));
            }

            // Plugin Root File.
            if (!defined('CW_PLUGIN_FILE')) {
                define('CW_PLUGIN_FILE', __FILE__);
            }
        }

        /**
         * Load plugins required files.
         *
         * @return void
         */
        private function includes()
        {
            require_once CW_PLUGIN_DIR . 'includes/cw-report-api.php';
            require_once CW_PLUGIN_DIR . 'includes/cw-report.php';
            require_once CW_PLUGIN_DIR . 'includes/cw-cron.php';
            require_once CW_PLUGIN_DIR . 'includes/cw-ajax.php';
            require_once CW_PLUGIN_DIR . 'includes/cw-pages.php';
        }

        /**
         * Hook in our actions and filters.
         *
         * @return void
         */
        private function init_hooks()
        {
            register_activation_hook(CW_PLUGIN_FILE, [$this, 'install']);
            register_deactivation_hook(CW_PLUGIN_FILE, [$this, 'uninstall']);
            add_action('plugins_loaded', [$this, 'load_textdomain'], 0);
            add_action('plugins_loaded', [$this, 'init'], 0);

            if (version_compare(get_bloginfo('version'), '5.8', '<')) {
                add_filter('site_transient_update_plugins', [$this, 'update']);
            } else {
                add_filter(
                    'update_plugins_raw.githubusercontent.com',
                    [$this, 'check_for_updates'],
                    10,
                    3
                );
            }

            add_action('admin_init', [$this, 'admin_init'], 0);
        }

        /**
         * Install plugin.
         *
         * @return void
         */
        public function install()
        {
            CW_Cron::install();
        }

        /**
         * Uninstall plugin.
         *
         * @return void
         */
        public function uninstall()
        {
            CW_Cron::uninstall();
        }

        /**
         * Load plugin textdomain.
         *
         * @return void
         */
        public function load_textdomain()
        {
            load_plugin_textdomain(
                'cw-report',
                false,
                basename(dirname(__FILE__)) . '/languages'
            );
        }

        /**
         * Hook into WordPress once all plugins are loaded.
         *
         * @return void
         */
        public function init()
        {
            add_action('admin_menu', [$this, 'admin_menu'], 0);
            new CW_Cron();
        }

        /**
         * Hook into WordPress init when a user accesses the admin area.
         *
         * @return void
         */
        public function admin_init()
        {
            $plugin_data = get_plugin_data(__FILE__);

            $this->version = $plugin_data['Version'];
            $this->UpdateURI = $plugin_data['UpdateURI'];
            $this->plugin_slug = plugin_basename(__DIR__);

            // Plugin version.
            if (!defined('CW_VERSION')) {
                define('CW_VERSION', $this->version);
            }
            new CW_Ajax();
        }

        /**
         * Creating a plugin settings page.
         *
         * @return void
         */
        public function admin_menu()
        {
            $menu = new CW_Pages();
            $menu->add_page(__('Generate', 'cw-report'), 'generate');
            $menu->add_page(__('Reports', 'cw-report'), 'reports');
            $menu->init();
        }

        /**
         * Check for update plugin.
         *
         * @return object
         */
        public function check_for_updates($update, $plugin_data, $plugin_file)
        {
            static $response = false;

            if (empty($plugin_data['UpdateURI']) || !empty($update)) {
                return $update;
            }

            if ($response === false) {
                $response = wp_remote_get($plugin_data['UpdateURI']);
            }

            if (empty($response['body'])) {
                return $update;
            }

            $custom_plugins_data = json_decode($response['body'], true);

            if (!empty($custom_plugins_data[$plugin_file])) {
                return $custom_plugins_data[$plugin_file];
            } else {
                return $update;
            }
        }

        /**
         * Get data for plugin.
         *
         * @return object
         */
        private function request()
        {
            $remote = get_transient($this->cache_key);

            if (false === $remote || !$this->cache_allowed) {
                $remote = wp_remote_get($this->UpdateURI, [
                    'timeout' => 10,
                    'headers' => [
                        'Accept' => 'application/json',
                    ],
                ]);

                if (
                    is_wp_error($remote) ||
                    200 !== wp_remote_retrieve_response_code($remote) ||
                    empty(wp_remote_retrieve_body($remote))
                ) {
                    return false;
                }

                set_transient($this->cache_key, $remote, DAY_IN_SECONDS);
            }

            $remote = json_decode(wp_remote_retrieve_body($remote));

            return $remote;
        }

        /**
         * Set data for plugin.
         *
         * @return object
         */
        public function update($transient)
        {
            if (empty($transient->checked)) {
                return $transient;
            }

            $plugin_id = CW_PLUGIN_ID;
            if (empty($this->checked)) {
                $remote = $this->request();
                if (!$remote || empty($remote->$plugin_id)) {
                    return $transient;
                }
                $this->checked = $remote->$plugin_id;
            }
            if (empty($this->checked)) {
                return $transient;
            }

            if (version_compare($this->version, $this->checked->version, '<')) {
                $res = new stdClass();
                $res->slug = $this->plugin_slug;
                $res->plugin = plugin_basename(__FILE__);
                $res->new_version = $this->checked->version;
                $res->tested = get_bloginfo('version');
                $res->package = $this->checked->package;

                $transient->response[$res->plugin] = $res;
            }

            return $transient;
        }

        /**
         * Throw error on object clone.
         *
         * The whole idea of the singleton design pattern is that there is a single
         * object therefore, we don't want the object to be cloned.
         *
         * @return void
         */
        public function __clone()
        {
            // Cloning instances of the class is forbidden
            _doing_it_wrong(
                __FUNCTION__,
                __('Cheatin&#8217; huh?', 'cw-report'),
                '1.0.0'
            );
        }

        /**
         * Disable unserializing of the class.
         *
         * @return void
         */
        public function __wakeup()
        {
            // Unserializing instances of the class is forbidden
            _doing_it_wrong(
                __FUNCTION__,
                __('Cheatin&#8217; huh?', 'cw-report'),
                '1.0.0'
            );
        }
    }
endif;

/**
 * Start CW_Tech_Report.
 *
 * @return CW_Tech_Report
 */
function CW_Tech_Report()
{
    return CW_Tech_Report::instance();
}

CW_Tech_Report();

if (defined('WP_CLI') && WP_CLI) {
    WP_CLI::add_command( 'report run', function () {
        try {
            $cron = new CW_Cron();
            if($cron->create_report()){
                WP_CLI::success('Report created');
            }else{
                WP_CLI::success('Report not created');
            }
        } catch (\Throwable $th) {
            WP_CLI::error( 'Error create CW Report' );
        }
        WP_CLI::success( 'End task create report' );
    } );
}
