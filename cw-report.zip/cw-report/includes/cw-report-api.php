<?php
/**
 * Function to contact Webpagetest API for CW Report plugin.
 *
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('CW_RA')) :
    /**
     * CW_RA class.
     */
    final class CW_RA
    {

        /**
         *  Instance.
         *
         * @var CW_Tech_Report the Instance
         */
        protected static $_instance;

        public $errors = null;

        private $api = 'https://reports.hostwithclark.com/api.php';

        /**
         * Main CW_Tech_Report Instance.
         *
         * Ensures that only one instance of CW_Tech_Report exists in memory at any one
         * time. Also prevents needing to define globals all over the place.
         *
         * @return CW_Tech_Report
         */
        public static function instance()
        {
            if (is_null(self::$_instance)) {
                try {
                    self::$_instance = new self();
                } catch (\Throwable $th) {
                    return null;
                }
            }

            return self::$_instance;
        }

        /**
         * Curl request to api
         * 
         * @param string $url relative URL for the call
         * 
         * @return response
         */
        private function call($url,$post = [])
        {
            if(!$post){
                $response = wp_remote_get( $url, ['timeout' => 30] );
            }else{
                $response = wp_remote_post( $url, ['timeout' => 30,'body' => $post ] );
            }
            return $response;
        }

        /**
         * Run test report.
         * 
         * @param array 
         * 
         * @return array 
         */
        public function get_cloudways() {
            $this->errors = [];
            $domain = parse_url(get_option( 'siteurl' ))['host'];
            $url = $this->api."?domain=".$domain."&action=cloudways";
            if(is_ssl()) $url .= "&ssl=true";
            $url .= "&wp=".get_bloginfo('version');

            $cloudways = $this->call( $url );
            
            if(is_wp_error($cloudways)) $this->errors[] = $cloudways->get_error_message();
            if($cloudways["response"]["code"]!=200) $this->errors[] = "Error report api!";
            
            $json = @json_decode($cloudways["body"],1);
            if(!$json) $this->errors[] = "Error parse report json!";
            else return $json;

            return false;
        }

        /**
         * Run test report.
         * 
         * @param array 
         * 
         * @return array 
         */
        public function run_lighthouse($mobile = 0,$report_id = 0) {
            $this->errors = [];
            $domain = parse_url(get_option( 'siteurl' ))['host'];
            $url = $this->api."?domain=".$domain."&action=pagetest&mobile=".$mobile;
            if($report_id>0) $url .= "&report_id=".$report_id;
            $lighthouse = $this->call( $url );
            
            if(is_wp_error($lighthouse)) {
                $this->errors[] = $lighthouse->get_error_message();
                return false;
            }
            if($lighthouse["response"]["code"]!=200) $this->errors[] = "Error report api!";
            
            $json = @json_decode($lighthouse["body"],1);
            if(!$json) $this->errors[] = "Error parse report json!";
            else return $json;

            return false;
        }

        /**
         * Get result report from url.
         * 
         * @param string 
         * 
         * @return array 
         */
        public function get_lighthouse_status($json_url) {
            $this->errors = [];
            if(!$json_url) return false;

            $responsive = $this->call($json_url);
            if(is_wp_error($responsive)){
                $this->errors[] = $responsive->get_error_message();
                return false;
            } 
            if($responsive["response"]['code']!==200){
                $this->errors[] = __( 'Error getting status lighthouse report', 'cw-report' );
                return false;
            }

            $json = @json_decode($responsive["body"],1);
            if(!$json) $this->errors[] = "Error parse status lighthouse report json!";
            if(!empty($json['data']['lighthouse'])){
                $data = $this->parseJsonResult($json['data']['lighthouse'],$json['data']['html_result_url']);
                if($data) return ["data" => $data];
                else $this->errors[] = __( 'Error parse report data', 'cw-report' );
                return false;
            }

            return $json['data'];
        }

        /**
         * Parse report data.
         * 
         * @param string 
         * 
         * @return array 
         */
        public function parseJsonResult($json,$full_report) {
            if($this->errors) return false;
            if(!$json) return false;
            
            $data = [];
            $data["Performance"] = ($json['categories']['performance']['score']*100)." / 100";
            $data["Accessibility"] = ($json['categories']['accessibility']['score']*100)." / 100";
            $data["Best Practices"] = ($json['categories']['best-practices']['score']*100)." / 100";
            $data["SEO"] = ($json['categories']['seo']['score']*100)." / 100";

            $data["First Contentful Paint"] = $json['audits']['first-contentful-paint']['displayValue'];
            $data["Time to Interactive"] = $json['audits']['interactive']['displayValue'];
            $data["Speed Index"] = $json['audits']['speed-index']['displayValue'];
            $data["Total Blocking Time"] = $json['audits']['total-blocking-time']['displayValue'];
            $data["Largest Contentful Paint"] = $json['audits']['largest-contentful-paint']['displayValue'];
            $data["Cumulative Layout Shift"] = $json['audits']['cumulative-layout-shift']['displayValue'];
            $data["Full Report"] = '<a href="'.$full_report.'">View</a>';
            
            return $data;
        }

        /**
         * Run test report.
         * 
         * @param array 
         * 
         * @return array 
         */
        public function get_pdf($data) {
            if(!$data) return false;

            $json = json_encode($data);
            if(!$json) return false;

            $domain = parse_url(get_option( 'siteurl' ))['host'];
            $response = $this->call($this->api."?domain=".$domain."&action=jsontopdf",['json' =>$json]);
            

            if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response )!=200) return false;
            if ( $response["headers"]->offsetGet("content-type") != "application/pdf" || intval($response["headers"]->offsetGet("content-length")) < 1000) return false;

            $filename = explode("=",$response["headers"]->offsetGet("content-disposition"))[1];
            if(!$filename) $filename = "report.pdf";

            $file = [];
            $file["type"] = $response["headers"]->offsetGet("content-type");
            $file["length"] = $response["headers"]->offsetGet("content-length");
            $file["filename"] = $filename;
            $file["body"] = $response['body'];

            if ($file) {
                header($_SERVER["SERVER_PROTOCOL"] . " 200 OK");
                header("Cache-Control: public"); 
                header("Content-Type: application/pdf");
                header("Content-Transfer-Encoding: Binary");
                header("Content-Length:".$file["length"]);
                header("Content-Disposition: attachment; filename=".$file["filename"]);
                echo ($file["body"]);
                die();
            }

            return false;
        }

    }

endif;

/**
 * Start CW_RA.
 *
 * @return CW_RA
 */
function CW_RA()
{
    return CW_RA::instance();
}
