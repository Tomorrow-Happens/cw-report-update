<?php
/**
 * CW_Report class for CW Report plugin.
 *
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('CW_Report')) :

    /**
     * CW_Report class.
     */
    class CW_Report
    {

        public $errors = [];

        private $id = 0;

        private $post = null;

        public static $post_type = 'cw_report';

        private $previous = null;

        private $type = 'full';
		
        private $site = '';

        private $period = '';

        private $data = [];

        private $details = [
            'app'        => 'Wordpress',
            'php'        => 'PHP',
            'platform'   => 'Platform',
            'mariadb'    => 'MariaDB',
            'redis'      => 'Redis'
        ];
  
        private $core = [
            "apache2"       => 'Apache2',
            "memcached"     => 'MemCached',
            "mysql"         => 'MySQL',
            "nginx"         => 'Nginx',
            "redis-server"  => 'Redis',
            "varnish"       => 'Varnish Cache',
            "ssl"           => 'SSL Encryption'
        ];

        private $security = [ 
            "protection"       => 'Comprehensive Protection',
            "frequency"     => 'Backup Frequency',
            "retention"         => 'Backup Retention',
        ];

        private $plugins = [];

        private $lighthouse = [
            "desktop"       => [],
            "mobile"        => []
		];
		
        private $notes = 'N/A';

        /**
         * Construct CW_Report class.
         *
         * @return void
         */
        public function __construct( $read = 0 ) {
			if ( is_numeric( $read ) && $read > 0 ) {
				$this->set_id( $read );
			} elseif ( $read instanceof self ) {
				$this->set_id( absint( $read->get_id() ) );
			} elseif ( ! empty( $read->ID ) ) {
				$this->set_id( absint( $read->ID ) );
			}
	
			if ( $this->get_id() > 0 ) {
				$this->read();
			}
        }

		/**
		 * Reads an object from the data store.
		 *
		 * @return CW_Report data instance.
		 */
		public function read() {
			$post_object = get_post( $this->get_id() );
			if ( ! $this->get_id() || ! $post_object || self::$post_type !== $post_object->post_type ) {
				$this->errors[] = __( 'Invalid read CW_Report post object', 'cw-report' );
				return $this;
			}
			$this->post = $post_object;
			$this->read_post_meta();
			return $this;
		}

		/**
		 * Read post meta.
         *
         * @return void
		 */
		protected function read_post_meta() {
			$id = $this->get_id();
			foreach($this->details as $name => $value){
				$this->data[$name] = get_post_meta( $id, '_'.$name, 1 );
			}
			foreach($this->core as $name => $value){
				$this->data[$name] = get_post_meta( $id, '_'.$name, 1 );
			}
			foreach($this->security as $name => $value){
				$this->data[$name] = get_post_meta( $id, '_'.$name, 1 );
			}
			$this->site = get_post_meta( $id, '_site', 1 );
			$this->period = get_post_meta( $id, '_period', 1 );
			$this->plugins = get_post_meta( $id, '_plugins', 1 );
			$this->lighthouse['mobile'] = get_post_meta( $id, '_lighthouse_mobile', 1 );
			$this->lighthouse['desktop'] = get_post_meta( $id, '_lighthouse_desktop', 1 );
		}

		/**
		 * Register custom post type cw_report.
         *
         * @return void
		 */
        public static function init() {
			$args = [
                'label' => __('CW Report', 'cw-report'),
                'public' => false,
                'show_in_menu' => null,
                'show_in_rest' => null,
                'rest_base' => null,
                'capability_type' => 'post',
                'hierarchical' => false,
                'has_archive' => false,
                'query_var' => false,
                'can_export' => false,
                'rewrite_no_front' => false,
                'rewrite' => false,
            ];
        
            register_post_type(self::$post_type, $args);
        }

	    /**
    	 * Returns the unique ID for this object.
    	 *
    	 * @return int
    	 */
    	public function get_id() {
    		return $this->id;
    	}

	    /**
    	 * Set the unique ID for this object.
    	 *
    	 * @param int
    	 */
    	private function set_id($id) {
    		$this->id = $id;
    	}

    	/**
    	 * Returns previous for this object.
    	 *
    	 * @return object
    	 */
    	public function get_previous() {
    		return $this->previous;
    	}

    	/**
    	 * Method to update previous for this object.
    	 *
    	 * @param object
    	 */
    	public function set_previous($previous) {
    		$this->previous = $previous;
    	}

    	/**
    	 * Returns type for this object.
    	 *
    	 * @return string
    	 */
    	public function get_type() {
    		return $this->type;
    	}

    	/**
    	 * Method to set type for this object.
    	 *
    	 * @param string
    	 */
    	public function set_type($type) {
    		$this->type = $type;
    	}

	    /**
    	 * Returns attibute data for this object.
    	 *
    	 * @return string
    	 */
    	public function get_param($param) {
    		if(isset($this->data[$param])) return $this->data[$param];
			else return 'N/A';
    	}

	    /**
    	 * Returns plugin for this object.
    	 *
    	 * @return array
    	 */
    	public function get_plugin($path) {
		$plugins = [];
		foreach($this->plugins as $plugin) $plugins[$plugin["Name"]] = $plugin;
    		if(isset($plugins[$path])) return $plugins[$path];
		else return false;
    	}

    	/**
    	 * Returns site for this object.
    	 *
    	 * @return string
    	 */
    	public function get_site() {
    		return $this->site;
    	}

    	/**
    	 * Method to update param site for this object.
    	 *
    	 * @param string
    	 */
    	public function set_site($site) {
    		$this->site = $site;
    	}

    	/**
    	 * Returns period for this object.
    	 *
    	 * @return string
    	 */
    	public function get_period() {
    		return $this->period;
    	}

    	/**
    	 * Returns period formated for this object.
    	 *
    	 * @return string
    	 */
    	public function get_period_month() {
			return get_post_datetime( $this->post, 'date', 'local' )->modify('-1 month')->format('F Y');
    	}

    	/**
    	 * Method to update param period for this object.
    	 *
    	 * @param string
    	 */
    	public function set_period($period) {
    		$this->period = $period;
    	}

    	/**
    	 * Returns notes for this object.
    	 *
    	 * @return string
    	 */
    	public function get_notes() {
    		return $this->notes?$this->notes:"N/A";
    	}

    	/**
    	 * Method to update param notes for this object.
    	 *
    	 * @param string
    	 */
    	public function set_notes($notes) {
    		$this->notes = $notes;
    	}

    	/**
    	 * Returns details for this object.
    	 *
    	 * @return array
    	 */
    	public function get_details() {
			$details = [];
            foreach($this->details as $name=>$label){
                if(!isset($this->data[$name])) continue;
                $detail = ["label" => $label,"current" => $this->data[$name]?$this->data[$name]:"N/A"];
				if($this->type == 'full'){
					if($this->previous) 
						$detail["previous"] =  $this->previous->get_param($name);
					else
						$detail["previous"] =  'N/A';
				}
				  
				$details[] = $detail;
            }
    		return $details;
    	}

    	/**
    	 * Method to update param details for this object.
    	 *
    	 * @param array
    	 */
    	public function set_details($details) {
			if(is_object($details)) $details = (array)$details;
			foreach($this->details as $name=>$label){
                if(!isset($details[$name])) continue;
                $this->data[$name] = $details[$name];
            }
		}

    	/**
    	 * Returns core for this object.
    	 *
    	 * @return array
    	 */
    	public function get_core() {
			$cores = [];
            foreach($this->core as $name=>$label){
                if(!isset($this->data[$name])) continue;
                $cores[] = ["label" => $label,"current" => ucfirst($this->data[$name])];
            }
    		return $cores;
    	}

    	/**
    	 * Method to update param core for this object.
    	 *
    	 * @param array
    	 */
    	public function set_core($core) {
			if(is_object($core)) $core = (array)$core;
			foreach($this->core as $name=>$label){
                if(!isset($core[$name])) continue;
                $this->data[$name] = $core[$name];
            }
		}

    	/**
    	 * Returns security for this object.
    	 *
    	 * @return array
    	 */
    	public function get_security() {
			$securities = [];
            foreach($this->security as $name=>$label){
                if(!isset($this->data[$name])) continue;
                $securities[] = ["label" => $label,"current" => ucfirst($this->data[$name])];
            }
    		return $securities;
    	}

    	/**
    	 * Method to update param security for this object.
    	 *
    	 * @param array
    	 */
    	public function set_security($security) {
			if(is_object($security)) $security = (array)$security;
			foreach($this->security as $name=>$label){
                if(!isset($security[$name])) continue;
                $this->data[$name] = $security[$name];
            }
		}

    	/**
    	 * Returns security for this object.
    	 *
    	 * @return array
    	 */
    	public function get_plugins() {
			$plugins = [];
            foreach($this->plugins as $path=>$plugin){
                $plugins[] = ["label" => $plugin["Name"],"current" => $plugin["Version"]];
            }
    		return $plugins;
    	}

    	/**
    	 * Method to update param plugins for this object.
    	 *
    	 */
    	public function set_plugins() {
			$active_plugins = get_option('active_plugins');
			$all_plugins=get_plugins();
			unset($all_plugins[CW_PLUGIN_ID]);
			$plugins=[];
			foreach ($active_plugins as $p){           
				if(isset($all_plugins[$p])){
					 array_push($plugins, $all_plugins[$p]);
				}           
			}
            $this->plugins = $plugins;
		}

    	/**
    	 * Returns security for this object.
    	 *
    	 * @return array
    	 */
    	public function get_updated_plugins() {
			$plugins = [];
            foreach($this->plugins as $path=>$plugin){
				$previous = [];
				if($this->previous) $previous = $this->previous->get_plugin($plugin["Name"]);
				if(!$previous || $plugin["Version"] == $previous["Version"])  continue;
                $plugins[] = ["label" => $plugin["Name"],"current" => $plugin["Version"],"previous" => $previous["Version"]];
            }
			if(!$plugins) $plugins[] = ["label" => "N/A","current" => "-","previous" => "-"];
    		return $plugins;
    	}

    	/**
    	 * Returns security for this object.
    	 *
    	 * @return array
    	 */
    	public function get_unchanged_plugins() {
			$plugins = [];
            foreach($this->plugins as $path=>$plugin){
				$previous = [];
				if($this->previous) $previous = $this->previous->get_plugin($plugin["Name"]);
				if($previous && $plugin["Version"] != $previous["Version"])  continue;
				$plugins[] = ["label" => $plugin["Name"],"current" => $plugin["Version"]];
            }
			if(!$plugins) $plugins[] = ["label" => "N/A","current" => "-"];
    		return $plugins;
    	}

    	/**
    	 * Returns lighthouse data for this object.
    	 *
    	 * @return array
    	 */
    	public function get_lighthouse($context = 'view') {
			switch ($context) {
				case 'view':
					$lighthouse = [];
					foreach ($this->lighthouse as $type => $data) {
						foreach ($data as $name=>$item) {
							if($this->type == 'full' && $this->previous){
								$previous = $this->previous->get_lighthouse('raw');
								if(isset($previous[$type][$name])){
									$lighthouse[$type][] = ["label" => $name, "current" => $item, "previous" => $previous[$type][$name]];
								}else{
									$lighthouse[$type][] = ["label" => $name, "current" => $item, "previous" => 'N/A'];
								}
							}else{
								$lighthouse[$type][] = ["label" => $name, "current" => $item];
							}
						}
					}
					return $lighthouse;
				default:
					return $this->lighthouse;
			}
		}

    	/**
    	 * Method to update lighthouse data for this object.
    	 *
    	 * @param array
    	 */
    	public function set_lighthouse($report,$mobile = 0) {
			if(!$report) return false;

			if($mobile == 1) $this->lighthouse['mobile'] = $report;
			else $this->lighthouse['desktop'] = $report;
			return true;
		}

    	/**
    	 * Returns json data for this object.
    	 *
    	 * @return string
    	 */
    	public function get_json() {
			$json = [];

            $json["site"] = $this->get_site();
            if($this->type == 'current') $json["period"] = $this->get_period();
			else $json["period"] = $this->get_period_month();
			$json["details"] = $this->get_details();
			$json["core"] = $this->get_core();
			$json["security"] = $this->get_security();

			if($this->type == 'current'){
				$json["plugins"] = $this->get_plugins();
			}else{
				$json["updatedPlugins"] = $this->get_updated_plugins();
				$json["unchangedPlugins"] = $this->get_unchanged_plugins();
			}

			$json["notes"] = $this->get_notes();
			if($this->lighthouse['mobile'] && $this->lighthouse['desktop']) $json["lighthouse"] = $this->get_lighthouse();

    		return $json;
    	}

		/**
		 * Save should create or update based on object existence.
		 *
		 * @return int
		 */
		public function save() {

			if ( $this->get_id() ) {
				$this->update();
			} else {
				$this->create();
			}

			return $this->get_id();
		}
	
		/**
		 * Method to create a post cw_report in the database.
		 */
		public function update() {
			$this->update_post_meta();
		}

		/**
		 * Method to create a post cw_report in the database.;
		 */
		public function create() {

			$id = wp_insert_post(
				apply_filters(
					'cw_report_new_post_data',
					array(
						'post_type'      => self::$post_type,
						'post_status'    => 'publish',
						'post_title'     => 'Report '.$this->get_period(),
						'comment_status' => 'closed',
						'ping_status'    => 'closed'
					)
				),
				true
			);

	        if ( $id && ! is_wp_error( $id ) ) {
				$this->set_id( $id );
				$this->update_post_meta();
				do_action( 'cw_report_new_post_'.self::$post_type, $id, $this );
			}else{
				$this->errors[] = __( 'Error create post cw_report in the database', 'cw-report' );
			}
		}
																			

		/**
		 * Method to update post meta a post cw_report in the database.;
		 */
		protected function update_post_meta() {
			$id = $this->get_id();
			foreach($this->data as $name => $value){
				update_post_meta( $id, '_'.$name, $value );
			}
			update_post_meta( $id, '_site', $this->site );
			update_post_meta( $id, '_period', $this->period );
			update_post_meta( $id, '_plugins', $this->plugins );
			if($this->lighthouse['mobile']) update_post_meta( $id, '_lighthouse_mobile', $this->lighthouse['mobile'] );
			if($this->lighthouse['desktop']) update_post_meta( $id, '_lighthouse_desktop', $this->lighthouse['desktop'] );
		}

		/**
		 * Delete an object, set the ID to 0, and return result.
		 *
		 * @return bool result
		 */
		public function delete() {
			$delete = wp_delete_post( $this->get_id(), 1 );
			if ( $delete ) {
				$this->set_id( 0 );
				return true;
			}
			return false;
		}


		/**
		 * Method to set previous report for this object.;
		 */
		public function set_previous_report(){
			$date = get_post_datetime( $this->post, 'date', 'local' );
			if(!$date) return true;

			$posts = get_posts([
				'posts_per_page' => 1,
				'orderby' => 'date',
				'order' => 'DESC',
				'post_type' => self::$post_type,
				'post_status' => 'publish',
				'date_query' => [
					'before'    => ['day'=>$date->format('d'), 'month' => $date->format('m'),'year' => $date->format('Y')]
				]
			]);

			if($posts){
				$this->previous = new CW_Report($posts[0]);
				return true;
			}
			return false;
		}
	}

endif;

CW_Report::init();


/**
 * Get CW_Report object.
 *
 * @return object
 */
function get_cw_report($id = 0){
    return new CW_Report($id);
}

/**
 * Get an array of CW_Report objects.
 *
 * @return array
 */
function get_cw_reports(){
	$posts = get_posts([
		'posts_per_page' => -1,
        'orderby' => 'date',
        'order' => 'DESC',
        'post_type' => CW_Report::$post_type,
        'post_status' => 'publish',
    ]);

	$reports=[];
	foreach ($posts as $post) {
		try {
			$reports[]=new CW_Report($post);
		} catch (\Throwable $th) {}
	}

	return $reports;
}

/**
 * Get an array of CW_Report date lists.
 *
 * @return array
 */
function get_cw_reports_periods(){
	$reports = get_cw_reports();

	$periods=[];
	foreach ($reports as $report) {
			$periods[$report->get_id()]=$report->get_period_month();
	}
    return $periods;
}

