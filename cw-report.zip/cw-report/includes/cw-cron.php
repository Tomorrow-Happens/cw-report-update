<?php
/**
 * CW_Cron class for CW Report plugin.
 *
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('CW_Cron')) :

    /**
     * CW_Cron class.
     */
    final class CW_Cron
    {

        public $errors = [];

        private $email = '';

        private $domain = '';

        public static $start_time = '01:00:00';

        public static $schedule = 'daily';

        /**
         * Construct CW_Cron.
         */
        function __construct() {
            $this->email = 'nate@tomorrow-happens.studio';
            $this->domain = parse_url(get_option( 'siteurl' ))['host'];

            if(parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH)=="/wpt-report/") 
                add_filter( 'init', function( ) { $this->wpt_report_page(); } );
             
            add_action('cw_report_cron_run', array($this, 'run'));     
            if(!wp_next_scheduled('cw_report_cron_run')){
                self::install();
            }
        }

        /**
         * Add wp schedule event.
         */
        public static function install() {
            if(wp_next_scheduled('cw_report_cron_run')) return false;
            wp_schedule_event( time(), self::$schedule, 'cw_report_cron_run');
        }

        /**
         * Delete wp schedule event.
         */
        public static function uninstall() {
            wp_clear_scheduled_hook( 'cw_report_cron_run' );
        }

        /**
         *  WP schedule event run this action.
         */
        public function run() {
            if(!wp_doing_cron()) return false;
            try {
                $this->create_report();
            } catch (\Throwable $th) {
                if(empty($settings->package_versions)) $this->error(__( "Error create CW Report for ", 'cw-report' ).$this->domain); 
            }
        }

        /**
         * Create report.
         * 
         */
        function create_report() {
            if(array_search(current_datetime()->modify('-1 month')->format('F Y'),get_cw_reports_periods()) !== false) return false;

            $cloudways = CW_RA()->get_cloudways();
            if(!$cloudways || CW_RA()->errors) $this->error(CW_RA()->errors);

            $report = new CW_Report();
            $report->set_site($this->domain);
            $report->set_period(current_datetime()->format('d F Y'));


            $report->set_details($cloudways["package"]);
            $report->set_core($cloudways["core"]);
            $report->set_security($cloudways["security"]);

            $report->set_plugins($security);
 
            if($report->errors) $this->error($report->errors);
            $report_id = $report->save();
            if($report_id){
                $this->generate_lighthouse($report_id);
                $this->generate_lighthouse($report_id,1);
                return true;
            } 
            else $this->error(__('Error save new CW Report', 'cw-report' ));

        }

        /**
         * Create lighthouse report.
         * 
         */
        private function generate_lighthouse($report_id,$mobile = 0) {

            $lighthouse = CW_RA()->run_lighthouse($mobile,$report_id);
            if(!$lighthouse || CW_RA()->errors) $this->error(CW_RA()->errors);

            if(empty($lighthouse['jsonUrl'])) $this->error("Error parse lighthouse report json!");
            return $lighthouse;
        }

        /**
         * Endpoint callback api for webpagetest pingback.
         * 
         */
        public function wpt_report_page() { 
            if(empty($_GET['report_id']) || empty($_GET['id'])) die('Error');
            
            list($report_id,$mobile) = explode("_",$_GET['report_id']);
            if((int)$report_id > 0) $cw_report = get_cw_report( $report_id );
            if(!$cw_report) error(__( "Lighthouse read cw_report error", 'cw-report' ));

            $url = "https://www.webpagetest.org/jsonResult.php?test=".$_GET['id'];
            $report = CW_RA()->get_lighthouse_status($url);
            if(empty($report["data"]) || $wpt->errors) $this->error(__( 'Error report result', 'cw-report' ));

            $cw_report->set_lighthouse($report["data"],(int)$mobile);
            $cw_report->save();

            wp_send_json( ['success' => "true"] );
            die();

        }

        /**
         * Callback error.
         */
        function error($error) {
            if(is_array($error)) $error = implode("\n- ",$error);
            if(is_a($error)) $error = print_r($errors,1);
            $subject = 'Error when cron report generate from '.$this->domain;
            $this->mail($error,$subject);
            die();
        }

        /**
         * Send email.
         */
        private function mail($message,$subject = '') {
            if($this->email) wp_mail( $this->email, $subject, $message );
        }
                
    }

endif;
