<?php
/**
 * Ajax action callbacks for CW Report plugin.
 *
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('CW_Ajax')) :

    /**
     * CW_Ajax class.
     */
    final class CW_Ajax
    {

        /**
         * Construct Ajax.
         */
        function __construct() {
            add_action('wp_ajax_generate_report', [$this,'generate_report']);
            add_action('wp_ajax_generate_report_pdf', [$this,'generate_report_pdf']);
            add_action('wp_ajax_generate_report_lighthouse', [$this,'generate_report_lighthouse']);
            add_action('wp_ajax_generate_lighthouse_status', [$this,'generate_lighthouse_status']);
        }

        /**
         * Ajax callback generate_report.
         */
        function generate_report() {
            $param = ["note"=>"N/A"];
            if(!empty($_POST["cw_report_note"])) $param["note"] = sanitize_text_field($_POST["cw_report_note"]);
            if(!empty($_POST["cw_report_period"])) $param["period"] = sanitize_text_field($_POST["cw_report_period"]);
          
            if($param["period"]=="current"){
                $this->current_report($param);
            }elseif((int)$param["period"]>0){
                $this->on_date_report($param);
            }
            $this->error(__( 'Error request execution', 'cw-report' ));
        }

        /**
         * Ajax callback generate current report.
         */
        private function current_report($param) {

            $cloudways = CW_RA()->get_cloudways();
            if(!$cloudways || $cloudways->errors) $this->error($cloudways->errors);

            $report = new CW_Report();

            $report->set_type('current');
            $report->set_site(parse_url(get_option( 'siteurl' ))['host']);
            $report->set_period(current_datetime()->format('d F Y'));
            $report->set_notes($param["note"]);

            $report->set_details($cloudways["package"]);
            $report->set_core($cloudways["core"]);
            $report->set_security($cloudways["security"]);

            $report->set_plugins();

            if(!empty($_POST["lighthouse"])){
                $lighthouse = json_decode(html_entity_decode(stripslashes($_POST["lighthouse"])),1);
                $report->set_lighthouse($lighthouse['mobile'],1);
                $report->set_lighthouse($lighthouse['desktop']);
            }
            if($report->errors) $this->error($report->errors);

            $report_data = $report->get_json();
            wp_send_json( $report_data );
            die();
        }

        /**
         * Ajax callback generate_report_lighthouse.
         */
        function generate_report_lighthouse() {
            $mobile = 0;
            if(!empty($_POST["mobile"])) $mobile = (int) $_POST["mobile"];

            $lighthouse = CW_RA()->run_lighthouse($mobile);
            if(!$lighthouse || CW_RA()->errors) $this->error(CW_RA()->errors);

            if(empty($lighthouse['jsonUrl'])) $this->error("Error parse lighthouse report json!");

            wp_send_json( $lighthouse );
            die();
        }

        /**
         * Ajax callback generate_lighthouse_status.
         */
        function generate_lighthouse_status() {
            if(empty($_POST["jsonUrl"])) $this->error(__( 'Error empty report url', 'cw-report' ));
            if($_POST["jsonUrl"] == 'none'){
                wp_send_json( ['data' => 'none'] );
                die();
            }
            $report = CW_RA()->get_lighthouse_status($_POST["jsonUrl"]);
            if(!$report || CW_RA()->errors) $this->error(CW_RA()->errors);
            if($report['statusCode'] < 200) sleep(20);
            wp_send_json( $report );
            die();
        }

        /**
         * The Ajax callback will generate a report by date.
         */
        private function on_date_report($param) {
            $report = get_cw_report($param["period"]);
            $report->set_notes($param["note"]);
            $report->set_previous_report();

            if($report->errors) $this->error($report->errors);

            $report_data = $report->get_json();

            wp_send_json( $report_data );
            die();
        }

        /**
         * Ajax callback generate_report_pdf.
         */
        function generate_report_pdf() {
            if(empty($_POST["json"])) $this->error(__( 'Error report json', 'cw-report' ));;

            $report_data = json_decode(html_entity_decode(stripslashes($_POST["json"])),1);
            if($report_data){
                $pdf = CW_RA()->get_pdf($report_data);
            }

            http_response_code(404);
            echo 'Not Found';
            die();
        }

        /**
         * Ajax callback error.
         */
        function error($errors) {
            if(is_string($errors)) $errors = [$errors];
            wp_send_json( ['errors'=>$errors] );
            die();
        }
            
    }

endif;
