<?php
/**
 * The Template for Generate admin page.
 *
 * @version 1.0.0
 */

if (!defined('ABSPATH')) exit; 
?>
<div class="wrap">
    <form id="cw-generate-form" >
        <input type="hidden" name="action" value="generate_report">
        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row"><?php _e( 'Notes', 'cw-report' ); ?></th>
                    <td><textarea name="cw_report_note" rows="10" cols="20" id="cw_report_note" class="large-text code"></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><?php _e( 'Period (required)', 'cw-report' ); ?></th>
                    <td><?php $periods = get_cw_reports_periods(); ?>
                        <select name="cw_report_period" id="cw_report_period" class="postform" required>
                            <option value="current" <?php echo $periods?'':'selected="selected"'; ?>><?php _e( 'Current Status Only', 'cw-report' ); ?></option>
                            <?php $first = key($periods); ?>
                            <?php foreach(get_cw_reports_periods() as $id => $period): ?>
                                <option value="<?php echo $id; ?>"  <?php echo $id == $first?'selected="selected"':''; ?>><?php echo $period; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
            </tbody>
        </table>
        <p class="cw_report_submit">
            <button type="button" id="cw_report_submit" class="button button-primary" onclick="generate_report();"><?php _e( 'Generate Report', 'cw-report' ); ?></button>
        </p>
        <div class="cw_report_status"></div>
    </form>
</div>
<div class="wrap" id="cw-report-form-output">
        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">
                        <p class="cw_report_label">
                        <?php _e( 'Report JSON', 'cw-report' ); ?>
                        </p>
                        <p class="cw_report_buttons">
                            <button type="button" id="cw_report_copy" class="button button-default" onclick="copy_report();"><?php _e( 'Copy to clipboard', 'cw-report' ); ?></button>
                            <button type="button" id="cw_report_clear" class="button button-default" onclick="jQuery('#cw_report_output').val('');"><?php _e( 'Clear', 'cw-report' ); ?></button>
                        </p>

                    </th>
                    <td>
                        <textarea name="cw_report_output" rows="20" id="cw_report_output" class="large-text code" readonly></textarea>
                    </td>
                </tr>
            </tbody>
        </table>
</div>
<script>
function generate_report(){
    if(!jQuery("#cw-generate-form")[0].checkValidity()){
        jQuery("#cw-generate-form")[0].reportValidity();
        return false;
    }
    jQuery("div#cw-report-form-output").removeClass('open');
    if(jQuery('#cw_report_period').val()=="current") generate_report_lighthouse();
    else generate_report_on_date();
    return ;
}
function generate_report_lighthouse(){
    new_preloader('Starting create lighthouse report');
    window.lighthouse = {"desktop":null, "mobile":null};
    run_report_lighthouse({"mobile": 0});
    run_report_lighthouse({"mobile": 1});
}
function run_report_lighthouse(param){
    log_preloader('Waiting for the report...'); 
    param.action = "generate_report_lighthouse";
    jQuery.ajax({
        type: "POST",
        url: ajaxurl,
        data: param,
        success: function (response) {
            if(response.errors || !response.jsonUrl){
                error_report(response);
                return false;
            }
            param.jsonUrl = response.jsonUrl; 
            get_lighthouse_status(param);
        },
	    error: function (jqXHR, exception) {
            jQuery('.cw_report_status').text('There was an error generating the report!').addClass('cw_error');
            jQuery("#cw_report_output").addClass('cw_error').val('Error response server');
            delete_preloader();
            return false;
	    }
    });
}
function get_lighthouse_status(param){
    param.action = "generate_lighthouse_status";
    jQuery.ajax({
        type: "POST",
        url: ajaxurl,
        data: param,
        success: function (response) {
            if(response.errors){
                error_report(response);
                return false;
            }
            if(response.statusCode < 200){
                get_lighthouse_status(param);
                log_preloader(response.statusText);
                return false;
            }
            if(response.data){
                if(param.mobile == 1) window.lighthouse.mobile = response.data;
                else  window.lighthouse.desktop = response.data;
                generate_report_current();
                return response.data;
            }
            jQuery('.cw_report_status').text('Sorry, Lighthouse had some issues gathering your report on WebPageTest. Please try again or try using Lighthouse with a different location!').addClass('cw_error');
            delete_preloader();
        },
	    error: function (jqXHR, exception) {
            jQuery('.cw_report_status').text('There was an error generating the report!').addClass('cw_error');
            jQuery("#cw_report_output").addClass('cw_error').val('Error response server');
            delete_preloader();
            return false;
	    }
    });
}
function generate_report_current(){
    if(window.lighthouse.mobile && window.lighthouse.desktop){
        log_preloader('Generating a current report...');
        let data = jQuery('#cw-generate-form').serializeArray();
        data.push({"name": "lighthouse", "value": JSON.stringify(window.lighthouse)});
        jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: data,
            success: function (response) {
                delete_preloader();
                if(response.errors){
                    jQuery('.cw_report_status').text('There was an error generating the report!').addClass('cw_error');
                    jQuery('#cw_report_output').addClass('cw_error');
                    let errors = '';
                    for (var key in response.errors) {
                        errors += "- " + response.errors[key] + "\n";
                    }
                    jQuery("#cw_report_output").val(errors);
                    return false;
                }
                jQuery('.cw_report_status').text('Report successfully generated.').addClass('cw_success');
                jQuery("#cw_report_output").val(JSON.stringify(response));
                get_report_pdf(JSON.stringify(response));
            },
	        error: function (jqXHR, exception) {
                jQuery('.cw_report_status').text('There was an error generating the report!').addClass('cw_error');
                jQuery("#cw_report_output").addClass('cw_error').val('Error response server');
                delete_preloader();
                return false;
	        }
        });

    }
}
function generate_report_on_date(){
    new_preloader('Generating a report on the server...');
    jQuery('.cw_report_status').text('Generating a report on the server...').removeClass('cw_error cw_success');
    jQuery('#cw_report_output').val('').removeClass('cw_error');
    jQuery.ajax({
        type: "POST",
        url: ajaxurl,
        data: jQuery('#cw-generate-form').serialize(),
        success: function (response) {
            if(response.errors){
                jQuery('.cw_report_status').text('There was an error generating the report!').addClass('cw_error');
                jQuery('#cw_report_output').addClass('cw_error');
                let errors = '';
                for (var key in response.errors) {
                    errors += "- " + response.errors[key] + "\n";
                }
                jQuery("#cw_report_output").val(errors);
                return false;
            }
            jQuery('.cw_report_status').text('Report successfully generated.').addClass('cw_success');
            jQuery("#cw_report_output").val(JSON.stringify(response));
            get_report_pdf(JSON.stringify(response));
        },
	    error: function (jqXHR, exception) {
            jQuery('.cw_report_status').text('There was an error generating the report!').addClass('cw_error');
            jQuery("#cw_report_output").addClass('cw_error').val('Error response server');
            delete_preloader();
            return false;
	    }
    });
}
function get_report_pdf(data){
    log_preloader('Generate pdf...'); 
    jQuery.ajax({
        type: "POST",
        url: ajaxurl,
        data: {
            action: "generate_report_pdf",
            json: data
        },
        xhrFields: {
            responseType: 'blob'
        },
        success: function (blob, status, xhr) {
            delete_preloader();
            if(!blob || status!='success'){
                jQuery("div#cw-report-form-output").addClass('open');
                return false;
            } 

            var filename = "";
            var disposition = xhr.getResponseHeader('Content-Disposition');
            if (disposition && disposition.indexOf('attachment') !== -1) {
                var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                var matches = filenameRegex.exec(disposition);
                if (matches != null && matches[1]) filename = matches[1].replace(/['"]/g, '');
            }

            if (typeof window.navigator.msSaveBlob !== 'undefined') {
                window.navigator.msSaveBlob(blob, filename);
            } else {
                var URL = window.URL || window.webkitURL;
                var downloadUrl = URL.createObjectURL(blob);

                if (filename) {
                    var a = document.createElement("a");
                    if (typeof a.download === 'undefined') {
                        window.location.href = downloadUrl;
                    } else {
                        a.href = downloadUrl;
                        a.download = filename;
                        document.body.appendChild(a);
                        a.click();
                    }
                } else {
                    window.location.href = downloadUrl;
                }

                setTimeout(function () { URL.revokeObjectURL(downloadUrl); }, 100);
            }
            return true;
        },
	    error: function (jqXHR, exception) {
            delete_preloader();
            jQuery("div#cw-report-form-output").addClass('open');
            return false;
	    }
    });
}

function copy_report(){
    let report = jQuery("#cw_report_output").val();
    if (navigator && navigator.clipboard && navigator.clipboard.writeText)
        return navigator.clipboard.writeText(report);
    alert('The Clipboard API is not available.');
}
function error_report(response){
    jQuery('.cw_report_status').text('There was an error generating the report!').addClass('cw_error');
    jQuery('#cw_report_output').addClass('cw_error');
    let errors = '';
    for (var key in response.errors) {
        errors += "- " + response.errors[key] + "\n";
    }
    jQuery("#cw_report_output").val(errors);
    delete_preloader();
}
function new_preloader(text){
    jQuery('#cw_report_submit')[0].disabled = true;
    jQuery('.cw_report_status').text('Generating a report on the server...').removeClass('cw_error cw_success');
    jQuery('#cw_report_output').val('').removeClass('th_error');
    jQuery('<div>').addClass('cw_preloader').append(jQuery('<div>')).append(jQuery('<p>').text(text)).appendTo(jQuery('body'));
}
function log_preloader(text){
    jQuery('div.cw_preloader p').text(text);
}
function delete_preloader(){
    jQuery('#cw_report_submit')[0].disabled = false;
    jQuery('div.cw_preloader').remove();
}
</script>
<style>
    #cw-generate-form input[type=text],
    #cw-generate-form textarea,
    #cw-generate-form select
    {
        width: 100%;
        max-width: 500px;
    }
    div#cw-report-form-output p.cw_report_label {
        padding-top: 0;
        margin-top: 0;
    }
    div#cw-report-form-output p.cw_report_buttons  button {
        font-size: 12px;
        display: block;
        margin-bottom: 5px;
        border: 1px solid #313131;
        color: #000;
    }
    .cw_report_status.cw_success {
        color: #009300;
    }
    .cw_report_status.cw_error {
        color: #f00;
    }
    #cw_report_output {
        background-color: #f7f7f7;
    }
    #cw_report_output.cw_error {
        color: #f00;
    }
    .cw_preloader {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    max-width: 100%;
    height: 100%;
    background: #0003;
    z-index: 99999;
    padding-top: 15%;
    overflow: hidden;
}

.cw_preloader>p {
    text-align: center;
    color: #337AB7;
    font-size: 22px;
}
    .cw_preloader>div {
    display: block;
    position: relative;
    width: 150px;
    height: 150px;
    margin: 30px auto;
    border-radius: 50%;
    border: 3px solid transparent;
    border-top-color: #337AB7;
    animation: cw_preloader-spin 2s linear infinite;
}
.cw_preloader>div:before {
    content: "";
    position: absolute;
    top: 5px;
    left: 5px;
    right: 5px;
    bottom: 5px;
    border-radius: 50%;
    border: 3px solid transparent;
    border-top-color: #BFE2FF;
    animation: preloader-5-spin 3s linear infinite;
}
.cw_preloader>div:after {
    content: "";
    position: absolute;
    top: 15px;
    left: 15px;
    right: 15px;
    bottom: 15px;
    border-radius: 50%;
    border: 3px solid transparent;
    border-top-color: #337AB7;
    animation: preloader-5-spin 1.5s linear infinite;
}
@keyframes cw_preloader-spin {
    0%   {
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
}

div#cw-report-form-output {
    display: none;
}

div#cw-report-form-output.open {
    display: block!important;
}

</style>