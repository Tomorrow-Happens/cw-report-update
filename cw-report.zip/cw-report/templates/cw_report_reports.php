<?php
/**
 * The Template for Generate admin page.
 *
 * @version 1.0.0
 */

if (!defined('ABSPATH')) exit; 
?>
<?php if(empty($_GET['action'])): ?>
<div class="wrap">
<table class="wp-list-table widefat fixed striped table-view-list posts">
	<thead>
	<tr>
        <th scope="col" id="title" class="manage-column column-title column-primary"><span>Period</span></th>
        <th scope="col" id="site" class="manage-column column-site">Domain</th>
        <th scope="col" id="wordpress" class="manage-column column-wordpress">Wordpress</th>
        <th scope="col" id="php" class="manage-column column-php">PHP</th>
        <th scope="col" id="plugins" class="manage-column column-plugins">Plugins</th>
        <th scope="col" id="date" class="manage-column column-date sortable asc"><span>Date</span></th>
    </tr>
	</thead>

	<tbody id="the-list">
    <?php foreach(get_cw_reports() as $report): ?>
	<tr>
		<td class="title column-title has-row-actions column-primary page-title" data-colname="Title">
            <strong><a class="row-title" href="/wp-admin/admin.php?page=cw_report_reports&action=view&id=<?php echo $report->get_id(); ?>" aria-label="View"><?php echo $report->get_period_month(); ?></a></strong>
            <div class="row-actions">
                <span class="view"><a href="/wp-admin/admin.php?page=cw_report_reports&action=view&id=<?php echo $report->get_id(); ?>" rel="bookmark" aria-label="View">View</a> | </span>
                <span class="delete"><a href="/wp-admin/admin.php?page=cw_report_reports&action=delete&id=<?php echo $report->get_id(); ?>" class="submitdelete" aria-label="Delete">Delete</a></span>
            </div>
        </td>
        <td class="site column-site" data-colname="site"><?php echo $report->get_site(); ?></td>
        <td class="wordpress column-wordpress" data-colname="Wordpress"><?php echo get_post_meta( $report->get_id(), '_app', 1 ); ?></td>
        <td class="php column-php" data-colname="PHP"><?php echo get_post_meta( $report->get_id(), '_php', 1 ); ?></td>
        <td class="plugins column-plugins" data-colname="Plugins"><?php echo count($report->get_plugins()); ?></td>
        <td class="date column-date" data-colname="Date"><?php echo get_post_datetime( $report->get_id(), 'date', 'local' )->format('d F Y h:i:s'); ?></td>
    		</tr>
            <?php endforeach; ?>
			</tbody>

	<tfoot>
	<tr>
        <th scope="col" id="title" class="manage-column column-title column-primary"><span>Period</span></th>
        <th scope="col" id="site" class="manage-column column-site">Domain</th>
        <th scope="col" id="wordpress" class="manage-column column-wordpress">Wordpress</th>
        <th scope="col" id="php" class="manage-column column-php">PHP</th>
        <th scope="col" id="plugins" class="manage-column column-plugins">Plugins</th>
        <th scope="col" id="date" class="manage-column column-date sortable asc"><span>Date</span></th>
    </tr>
	</tfoot>

</table>
</div>
<?php elseif($_GET['action'] == "view" && !empty($_GET['id'])): ?>
    <?php $report = get_cw_report((int)$_GET['id']); ?>
    <?php if($report && !$report->errors): ?>
        <?php $report = get_cw_report((int)$_GET['id']); ?>
        <?php $report->set_previous_report(); ?>
        <?php $json = $report->get_json(); ?>
        <div class="wrap">
            <h2><?php echo $report->get_period_month(); ?></h2>
            <table class="form-table cw_report_table_view" role="presentation">
            <tbody>
                <?php foreach($json as $name=>$param): ?>
                <tr>
                    <th scope="row"><?php echo ucfirst($name); ?></th>
                    <td>
                    <?php if(is_array($param)): ?>
                        <?php foreach($param as $key=>$value): ?>
                            <?php if(!isset($value['label'])): ?>
                                <div class="cw_report_subvalue_blk">
                                <div class="cw_report_subvalue"><?php echo ucfirst($key); ?></div>
                                <?php foreach($value as $k=>$v): ?>
                                    <div class="cw_report_value">
                                        <div><?php echo ucfirst($v['label']); ?></div>
                                        <div><?php echo $v['current']; ?><?php echo (!empty($v['previous']))?" (".$v['previous'].") ":""; ?></div>
                                    </div>
                                <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                            <div class="cw_report_value">
                                <div><?php echo ucfirst($value['label']); ?></div>
                                <div><?php echo $value['current']; ?><?php echo (!empty($value['previous']))?" (".$value['previous'].") ":""; ?></div>
                            </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <?php echo $param; ?>
                    <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php else: ?>
            <div class="wrap">
                <h2>Error, read report!</h2>
            </div>
        <?php endif; ?>
<?php 
elseif($_GET['action'] == "delete" && !empty($_GET['id'])): 
    $report = get_cw_report((int)$_GET['id']);
    if($report && !$report->errors) $report->delete();
    wp_redirect( '/wp-admin/admin.php?page=cw_report_reports' );
    die();
else: ?>
    <div class="wrap">
        <h2>Error, empty this report!</h2>
    </div>
<?php endif; ?>
<style>
table.cw_report_table_view {
    max-width: 800px;
}
table.cw_report_table_view th,
table.cw_report_table_view td
{
    position: relative;
}
table.cw_report_table_view th:before,
table.cw_report_table_view td:before
{
    border-top: 1px solid #9f9f9f;
    content: "";
    position: absolute;
    top: 0;
    width: 100%;
    height: 1px;
    display: block;
}
.cw_report_subvalue_blk .cw_report_value {
    padding-left: 100px;
}
.cw_report_subvalue {
    font-weight: bold;
    border-bottom: 1px solid #9f9f9f;
    margin-bottom: 15px;
    margin-top: 20px;
    line-height: 30px;
}
.cw_report_value {
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-content: center;
    align-items: center;
    justify-content: space-between;
    line-height: 30px;
}
</style>